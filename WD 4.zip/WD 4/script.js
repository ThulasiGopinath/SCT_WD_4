// Global array to store tasks
let tasks = [];

// Function to add a task
function addTask() {
    const taskInput = document.getElementById('task-input');
    const taskTime = document.getElementById('task-time');
    
    // Get task details
    const taskDescription = taskInput.value.trim();
    const taskDateTime = taskTime.value;

    if (taskDescription === '') {
        alert('Please enter a task!');
        return;
    }

    // Create new task object
    const newTask = {
        id: Date.now(),
        description: taskDescription,
        dateTime: taskDateTime ? taskDateTime : '',
        completed: false
    };

    // Add task to the tasks array
    tasks.push(newTask);

    // Clear inputs
    taskInput.value = '';
    taskTime.value = '';

    // Update the task list
    renderTasks();
}

// Function to render the task list
function renderTasks() {
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';

    tasks.forEach(task => {
        const taskItem = document.createElement('li');
        taskItem.classList.add('task-item');
        if (task.completed) taskItem.classList.add('completed');

        // Create task content
        taskItem.innerHTML = `
            <span>
                ${task.description} 
                ${task.dateTime ? `<small>(${formatDateTime(task.dateTime)})</small>` : ''}
            </span>
            <div>
                <button onclick="editTask(${task.id})">Edit</button>
                <button onclick="toggleCompletion(${task.id})">${task.completed ? 'Undo' : 'Complete'}</button>
                <button onclick="deleteTask(${task.id})">Delete</button>
            </div>
        `;

        // Append task item to the task list
        taskList.appendChild(taskItem);
    });
}

// Function to toggle task completion
function toggleCompletion(taskId) {
    const task = tasks.find(t => t.id === taskId);
    task.completed = !task.completed;
    renderTasks();
}

// Function to delete a task
function deleteTask(taskId) {
    tasks = tasks.filter(t => t.id !== taskId);
    renderTasks();
}

// Function to edit a task
function editTask(taskId) {
    const task = tasks.find(t => t.id === taskId);
    const newDescription = prompt('Edit Task:', task.description);
    if (newDescription !== null) {
        task.description = newDescription;
        renderTasks();
    }
}

// Function to clear completed tasks
function clearCompleted() {
    tasks = tasks.filter(t => !t.completed);
    renderTasks();
}

// Format the date and time in a readable format
function formatDateTime(dateTime) {
    const date = new Date(dateTime);
    const options = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric' };
    return date.toLocaleString('en-US', options);
}

// Initial render of the task list
renderTasks();
